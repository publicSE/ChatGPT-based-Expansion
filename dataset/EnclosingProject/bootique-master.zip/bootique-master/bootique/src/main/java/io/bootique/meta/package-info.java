/**
 * Metadata facilities describing Bootique application, its command-line interface (CLI), runtime modules and available
 * configurations.
 */
package io.bootique.meta;