package io.bootique;

class ApplicationDescription {

    private String description;

    public ApplicationDescription() {
    }

    public ApplicationDescription(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }
}
