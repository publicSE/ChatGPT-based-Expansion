package io.bootique.it;

import com.google.inject.Binder;
import com.google.inject.Module;

public class ItestModule implements Module {

	@Override
	public void configure(Binder binder) {
		// do nothing for now
	}

}
