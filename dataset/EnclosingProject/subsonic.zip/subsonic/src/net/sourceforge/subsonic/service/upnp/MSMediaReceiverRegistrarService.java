package net.sourceforge.subsonic.service.upnp;

import org.fourthline.cling.support.xmicrosoft.AbstractMediaReceiverRegistrarService;

/**
 * @author Sindre Mehus
 * @version $Id: MSMediaReceiverRegistrarService.java 3442 2013-04-24 19:31:47Z sindre_mehus $
 */
public class MSMediaReceiverRegistrarService extends AbstractMediaReceiverRegistrarService {
}
