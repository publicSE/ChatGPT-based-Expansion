@retrofit2.internal.EverythingIsNonNull
package retrofit2.adapter.scala;
